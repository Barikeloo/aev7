﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EjemploFechasHoras
{
    public partial class Frmppal : Form
    {
        private DateTime tiempo;
        public Frmppal()
        {
            InitializeComponent();
        }

        private void Frmppal_Load(object sender, EventArgs e)
        {
            lblHora.Text = DateTime.Now.ToString("HH:mm:ss");

            // Cargo en el datagrid todos los fichajes existentes en la BD
            if (ConBD.Conexion != null)
            {
                ConBD.AbrirConexion();
                dgvFichajes.DataSource = Fichaje.ListadoFichajes();
                ConBD.CerrarConexion();

            }
        }

        private void tmrReloj_Tick(object sender, EventArgs e)
        {
            lblHora.Text = DateTime.Now.ToString("HH:mm:ss");
            lblFecha.Text = DateTime.Now.ToString("dd-mm-yyyy");
            tiempo = DateTime.Now;
            
        }

        

        private void btnEntrada_Click_1(object sender, EventArgs e)
        {
            if (!Empleado.CalcLetra(txtNif.Text))
            {
                ptbFlorida.Visible = false;
                txtMessage.Text = "El NIF no es correcto";
            }
            else
            {
                try
                {
                    if (ConBD.Conexion != null)
                    {
                        ConBD.AbrirConexion();
                        List<Empleado> lista = new List<Empleado>();
                        lista = Empleado.BuscarEmpleado(txtNif.Text);
                        if (lista.Count > 0 && lista[0].Nif == txtNif.Text)
                        {
                            if (Empleado.comprobarEntrada(txtNif.Text))
                            {
                                ptbFlorida.Visible = false;
                                txtMessage.Text = "Empleado ya ha fichado";
                            }
                            else
                            {
                                Empleado.FicharEntrada(txtNif.Text, lblHora.Text, tiempo);
                                ptbFlorida.Visible = false;
                                txtMessage.Text = "Fichaje realizado correctamente";
                            }
                        }
                        else
                        {
                            MessageBox.Show("No se ha podido realizar");
                        }

                    }
                    else
                    {
                        MessageBox.Show("No se ha podido abrir la conexión con la Base de Datos");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message + "\n" + ex.StackTrace);
                }
                finally
                {
                    ConBD.CerrarConexion();
                }
            }
        }

        private void btnSalida_Click(object sender, EventArgs e)
        {
            if (!Empleado.CalcLetra(txtNif.Text))
            {
                ptbFlorida.Visible = false;
                txtMessage.Text = "El NIF no es correcto";
            }
            else
            {
                try
                {
                    if (ConBD.Conexion != null)
                    {
                        ConBD.AbrirConexion();
                        List<Empleado> lista = new List<Empleado>();
                        lista = Empleado.BuscarEmpleado(txtNif.Text);
                        if (lista.Count > 0 && lista[0].Nif == txtNif.Text)
                        {
                            if (Empleado.comprobarSalida(txtNif.Text))
                            {
                                ptbFlorida.Visible = false;
                                txtMessage.Text = "Empleado ya ha salido";
                            }
                            else
                            {
                                Empleado.FicharSalida(txtNif.Text, lblHora.Text, tiempo);
                                ptbFlorida.Visible = false;
                                txtMessage.Text = "Salida realizado correctamente";
                            }
                        }
                        else
                        {
                            MessageBox.Show("No se ha podido Salir");
                        }
                    }
                    else
                    {
                        MessageBox.Show("No se ha podido abrir la conexión con la Base de Datos");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message + "\n" + ex.StackTrace);
                }
                finally
                {
                    ConBD.CerrarConexion();
                }
            }
        }

        private void btnPresencia_Click(object sender, EventArgs e)
        { 
            if (!Empleado.CalcLetra(txtNif.Text))
            {
                ptbFlorida.Visible = false;
                txtMessage.Text = "El NIF no es correcto";
            }
            else
            {
                try
                {
                    if (ConBD.Conexion != null)
                    {
                        ConBD.AbrirConexion();
                        List<Empleado> lista = new List<Empleado>();
                        lista = Empleado.BuscarEmpleado(txtNif.Text);
                        if (lista.Count > 0 && lista[0].Nif == txtNif.Text)
                        {
                            if (Empleado.comprobarEntrada(txtNif.Text))
                            {
                                if (Empleado.comprobarSalida(txtNif.Text))
                                {
                                    ptbFlorida.Visible = false;
                                    txtMessage.Text = "Empleado ya ha fichado";
                                }
                                else
                                {
                                    Empleado.FicharSalida(txtNif.Text, lblHora.Text, tiempo);
                                    ptbFlorida.Visible = false;
                                    txtMessage.Text = "Salida realizado correctamente";
                                }
                            }
                            else
                            {
                                Empleado.FicharEntrada(txtNif.Text, lblHora.Text, tiempo);
                                ptbFlorida.Visible = false;
                                txtMessage.Text = "Fichaje realizado correctamente";
                            }
                        }
                        else
                        {
                            MessageBox.Show("No se ha podido realizar");
                        }
                    }
                    else
                    {
                        MessageBox.Show("No se ha podido abrir la conexión con la Base de Datos");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message + "\n" + ex.StackTrace);
                }
                finally
                {
                    ConBD.CerrarConexion();
                }
            }
        }
    }
}
